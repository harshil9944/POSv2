<div class="sidebar">
    <?php echo _get_module('core/menu'); ?>
</div>
