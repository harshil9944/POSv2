<script>new Vue({el:'#page-container'});</script>
</body>
</html>
