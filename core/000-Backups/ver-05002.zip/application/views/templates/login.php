<?php $cb = $this->brahma; ?>
<?php _view('templates/brahma/global'); ?>
<?php _eview('templates/brahma/components/head_start'); ?>
<?php _eview('templates/brahma/components/head_end'); ?>
<?php _eview('templates/brahma/components/page_start'); ?>
<?php echo _get_page_content(); ?>
<?php _eview('templates/brahma/components/page_end'); ?>
<?php _eview('templates/brahma/components/footer_start'); ?>
<?php _eview('templates/brahma/components/footer_end'); ?>
