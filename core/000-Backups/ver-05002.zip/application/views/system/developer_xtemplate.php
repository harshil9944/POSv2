<script type="text/x-template" id="developer-template">
    <div class="row">
        <div class="col-12">
            <b-button @click="handleSetPrintServer" variant="danger">Set this PC as Primary Print Server</b-button>
        </div>
    </div>
</script>