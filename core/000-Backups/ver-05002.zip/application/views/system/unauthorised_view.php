<div class="row">
    <div class="col-md-12">
        <h4>You are not allowed to access this page.</h4>
        <a href="javascript:history.go(-1)">Go Back</a>
    </div>
</div>
