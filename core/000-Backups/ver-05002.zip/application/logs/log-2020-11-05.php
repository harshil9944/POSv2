<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-05 18:01:43 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:01:43 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:01:46 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:01:47 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:01:50 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:01:50 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:01:54 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:03:06 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:03:06 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:36:59 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:36:59 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:39:43 --> 404 Page Not Found: /index
ERROR - 2020-11-05 18:39:43 --> 404 Page Not Found: /index
