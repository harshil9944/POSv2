<?php
//Development
defined('DEV_APPLICATION_DIR')          OR  define('DEV_APPLICATION_DIR', '../core/application');
defined('DEV_SYSTEM_DIR')               OR  define('DEV_SYSTEM_DIR', '../core/system');
defined('DEV_VIEW_DIR')                 OR  define('DEV_VIEW_DIR', '');
defined('DEV_ASSET_URL')                OR  define('DEV_ASSET_URL', 'http://assets.inntech.pos/');

defined('DEV_DEFAULT_TIMEZONE')         OR  define('DEV_DEFAULT_TIMEZONE', 'Asia/Kolkata');
defined('DEV_DEFAULT_TIMEZONE_VALUE')   OR  define('DEV_DEFAULT_TIMEZONE_VALUE', '+05:30');

//Live
defined('LIVE_APPLICATION_DIR')         OR  define('LIVE_APPLICATION_DIR', '../core/application');
defined('LIVE_SYSTEM_DIR')              OR  define('LIVE_SYSTEM_DIR', '../core/system');
defined('LIVE_VIEW_DIR')                OR  define('LIVE_VIEW_DIR', '');
defined('LIVE_ASSET_URL')               OR  define('LIVE_ASSET_URL', 'https://assets.pos.divaasolutions.com/');

defined('LIVE_DEFAULT_TIMEZONE')        OR  define('LIVE_DEFAULT_TIMEZONE', 'America/Edmonton');
defined('LIVE_DEFAULT_TIMEZONE_VALUE')  OR  define('LIVE_DEFAULT_TIMEZONE_VALUE', '-06:00');

//Constants
defined('UPDATE_CHECK_INTERVAL')        OR define('UPDATE_CHECK_INTERVAL', 10000);
defined('ORDER_METHODS')                OR define('ORDER_METHODS', 'p,d,dine');
defined('ALLOW_OPEN_CASH_DRAWER')       OR define('ALLOW_OPEN_CASH_DRAWER', false);
defined('SORT_VARIATION_BY_NAME')       OR  define('SORT_VARIATION_BY_NAME',false);

defined('DEFAULT_CASHIER_PRINT')        OR  define('DEFAULT_CASHIER_PRINT',false);
defined('DEFAULT_KITCHEN_PRINT')       OR  define('DEFAULT_KITCHEN_PRINT',false);

defined('ENABLE_SOURCE_SWITCH')         OR  define('ENABLE_SOURCE_SWITCH',false);
defined('START_WEB_ORDERS_WITH_SESSION')OR  define('START_WEB_ORDERS_WITH_SESSION',false);

defined('PLAY_SOUND_ON_NEW_ORDER')      OR  define('PLAY_SOUND_ON_NEW_ORDER',false);
defined('DEFAULT_WEB_ORDER_SOUND')      OR  define('DEFAULT_WEB_ORDER_SOUND','audio1.wav');
defined('ALLOW_REFUND')                 OR  define('ALLOW_REFUND',true);
defined('ENABLE_REPEAT_ORDER')          OR  define('ENABLE_REPEAT_ORDER',true);
defined('TABLET_GROUP_ID')              OR  define('TABLET_GROUP_ID', 10);
