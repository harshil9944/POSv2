<?php



$lang['error_delete_item_not_found']        = 'Unable to find the item you wanted to delete.';
$lang['error_cannot_delete_item']           = 'You cannot delete this item because it is associated with any Purchase, Sale or Transfer.';
$lang['error_cannot_delete_protected_item'] = 'You cannot delete a protected item.';
