<?php
defined('SYS_MIGRATION_PATH')     OR define('SYS_MIGRATION_PATH', MODULES_PATH . '/core/migrations/');
defined('SYS_MIGRATION_TABLE')    OR define('SYS_MIGRATION_TABLE', 'mig_core');

defined('SYS_PAYMENT_METHOD_TABLE') OR  define('SYS_PAYMENT_METHOD_TABLE', 'sys_payment_method');
defined('SYS_UNIT_TABLE')           OR  define('SYS_UNIT_TABLE', 'sys_unit');
defined('SYS_CARRIER_TABLE')        OR  define('SYS_CARRIER_TABLE', 'sys_carrier');
defined('SYS_COUNTRY_TABLE')        OR  define('SYS_COUNTRY_TABLE', 'sys_country');
defined('SYS_STATE_TABLE')          OR  define('SYS_STATE_TABLE', 'sys_state');
defined('SYS_APP_CURRENCY_TABLE')   OR  define('SYS_APP_CURRENCY_TABLE', 'sys_app_currency');
