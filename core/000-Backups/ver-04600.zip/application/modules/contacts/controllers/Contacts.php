<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contacts extends MY_Controller {

    public $module = 'contacts';
    public $model = 'contact';
    public $singular = 'Contact';
    public $plural = 'Contacts';
    public $language = 'contacts/contacts';
    public $edit_form = '';
    public function __construct()
    {

        parent::__construct();
        _model($this->model);
        $params = [
            'migration_path' => CONTACT_MIGRATION_PATH,
            'migration_table' => CONTACT_MIGRATION_TABLE
        ];
        $this->init_migration($params);
    }

    // Public methods Start

    /*public function customers()	{

        _language('contacts');
        _library('table');

        $results = $this->{$this->model}->get_customer_list();

        $body = [];
        if($results) {
            foreach ($results as $result) {
                $action = _edit_link(base_url($this->module.'/edit/'.$result['id'])) . _vue_delete_link('handleRemove('.$result['id'].')');
                $action_cell = [
                    'class' =>  'text-center',
                    'data'  =>  $action
                ];
                $receivables_cell = [
                    'class' =>  'text-right',
                    'data'  =>  custom_money_format(0.00,'₹')
                ];
                $payables_cell = [
                    'class' =>  'text-right',
                    'data'  =>  custom_money_format(0.00,'₹')
                ];
                $body[] = [
                    $result['display_name'],
                    $result['company_name'],
                    $result['email'],
                    $result['phone'],
                    $receivables_cell,
                    $payables_cell,
                    $action_cell
                ];
            }
        }

        $heading = [
            'Name',
            'Company Name',
            'Email',
            'Phone',
            'Receivables',
            'Payables',
            array('data'=>'Action','class'=>'text-center no-sort')
        ];

        _vars('table_heading',$heading);
        _vars('table_body',$body);
        $table = _view(DATA_TABLE_PATH);

        $page = [
            'singular'      =>  $this->singular,
            'plural'        =>  $this->plural,
            'add_url'       =>  base_url($this->module.'/add'),
            'vue_add_url'   =>  '',
            'table'         =>  $table,
            'edit_form'     =>  ''
        ];
        _vars('page_data',$page);
        _set_additional_component(LIST_XTEMPLATE_PATH,'outside');
        _set_layout_type('wide');
        _set_page_heading('Customers');
        _set_layout(LIST_VIEW_PATH);

    }

    public function vendors()	{

        _language('contacts');
        _library('table');

        $results = $this->{$this->model}->get_vendor_list();

        $body = [];
        if($results) {
            foreach ($results as $result) {
                $action = _edit_link(base_url($this->module.'/edit/'.$result['id'])) . _vue_delete_link('handleRemove('.$result['id'].')');
                $action_cell = [
                    'class' =>  'text-center',
                    'data'  =>  $action
                ];
                $receivables_cell = [
                    'class' =>  'text-right',
                    'data'  =>  custom_money_format(0.00,'₹')
                ];
                $payables_cell = [
                    'class' =>  'text-right',
                    'data'  =>  custom_money_format(0.00,'₹')
                ];
                $body[] = [
                    $result['display_name'],
                    $result['company_name'],
                    $result['email'],
                    $result['phone'],
                    $receivables_cell,
                    $payables_cell,
                    $action_cell
                ];
            }
        }

        $heading = [
            'Name',
            'Company Name',
            'Email',
            'Phone',
            'Receivables',
            'Payables',
            array('data'=>'Action','class'=>'text-center no-sort')
        ];

        _vars('table_heading',$heading);
        _vars('table_body',$body);
        $table = _view(DATA_TABLE_PATH);

        $page = [
            'singular'      =>  $this->singular,
            'plural'        =>  $this->plural,
            'add_url'       =>  base_url($this->module.'/add'),
            'vue_add_url'   =>  '',
            'table'         =>  $table,
            'edit_form'     =>  ''
        ];
        _vars('page_data',$page);
        _set_additional_component(LIST_XTEMPLATE_PATH,'outside');
        _set_layout_type('wide');
        _set_page_heading('Vendors');
        _set_layout(LIST_VIEW_PATH);

    }

    public function add() {

        $this->_add();

    }

    public function edit($id) {

        $this->_edit($id);

    }

    public function remove($id) {
        if(_can('contacts/remove')){

        }
    }*/

    //Public methods End

    public function _get_menu() {

        $menus = [];

        $contacts = [];
        $contacts[] = array(
            'name'	    =>  'Customers',
            'class'     =>  '',
            'group'     =>  '',
            'icon'      =>  'basket-loaded',
            'path'      =>  'contacts/customers',
            'module'    =>  'contacts',
            'children'  =>  []
        );

        $contacts[] = array(
            'name'	    =>  'Vendors',
            'class'     =>  '',
            'group'     =>  '',
            'icon'      =>  'basket-loaded',
            'path'      =>  'contacts/vendors',
            'module'    =>  'contacts',
            'children'  =>  []
        );

        $menus[] = array(
            'id'        => 'menu-contacts',
            'class'     => '',
            'icon'      => 'si si-users',
            'group'     => 'module',
            'name'      => 'Contacts',
            'path'      => 'contacts',
            'module'    => 'contacts',
            'priority'  => 1,
            'children'  => $contacts
        );

        return $menus;

    }

    /*public function _populate_get() {

        $statuses = get_status_array();

        $params = [];
        $params['include_select'] = true;
        $salutations = _get_module('contacts/salutations','_get_select_data',$params);
        $currencies = _get_module('core/currencies','_get_select_data',$params);

        _response_data('salutations',$salutations);
        _response_data('currencies',$currencies);
        _response_data('statuses',$statuses);
        return true;

    }

    public function _action_put() {
        _model('contacts/address','address');
        $obj = _input('obj');
        $this->_prep_obj($obj);

        //Add Billing Address
        $this->address->insert($obj['billing']);
        $obj['baddress_id'] = $this->address->insert_id();
        //Add Shipping Address
        $this->address->insert($obj['shipping']);
        $obj['saddress_id'] = $this->address->insert_id();

        $obj['status'] = 1;
        $obj['added'] = sql_now_datetime();
        unset($obj['id']);
        unset($obj['billing']);
        unset($obj['shipping']);

        if($this->{$this->model}->insert($obj)) {
            $id = $this->{$this->model}->insert_id();
            $redirect = ($obj['type']=='c')?base_url($this->module.'/customers'):base_url($this->module.'/vendors');
            _response_data('redirect',$redirect);
        }else{
            _response_data('message','Something wrong. Please try again.');
        }
        return true;
    }

    public function _action_post() {
        _model('contacts/address','address');
        $obj = _input('obj');
        $this->_prep_obj($obj);

        //Add Billing Address
        $this->address->replace($obj['billing']);

        //Add Shipping Address
        $this->address->replace($obj['shipping']);

        $id = $obj['id'];

        unset($obj['id']);
        unset($obj['billing']);
        unset($obj['shipping']);

        $filter=[
            'id'    =>  $id
        ];

        if($this->{$this->model}->update($obj,$filter)) {
            $redirect = ($obj['type']=='c')?base_url($this->module.'/customers'):base_url($this->module.'/vendors');
            _response_data('redirect',$redirect);
        }else{
            _response_data('message','Something wrong. Please try again.');
        }
        return true;
    }

    public function _action_delete() {

        $ignore_list = [];

        $id = _input('id');

        if(!in_array($id,$ignore_list)) {

            $filter = ['id' => $id];

            $result = $this->{$this->model}->single($filter);

            if($result) {

                $affected_rows = $this->{$this->model}->delete($filter);

                if ($affected_rows) {
                    _response_data('redirect', base_url($this->module));
                    return true;
                } else {
                    return false;
                }

            }else{
                _response_data('message','You cannot delete a protected size.');
                return false;
            }
        }else{
            _response_data('message','You cannot delete a protected size.');
            return false;
        }
    }

    private function _prep_obj(&$obj) {
        $contact_keys = $this->{$this->model}->keys;
        $address_keys = $this->address->keys;
        foreach ($contact_keys as $old => $new) {
            change_array_key($old,$new,$obj);
        }
        foreach ($address_keys as $old => $new) {
            change_array_key($old,$new,$obj['billing']);
        }
        foreach ($address_keys as $old => $new) {
            change_array_key($old,$new,$obj['shipping']);
        }
    }

    public function _single_get() {
        _model('contacts/address','address');

        $contact_keys = $this->{$this->model}->keys;
        $address_keys = $this->address->keys;

        $id = _input('id');
        $filter = ['id'=>$id];
        $result = $this->{$this->model}->single($filter);
        $contact_exclude_fields = $this->{$this->model}->exclude_keys;
        $address_exclude_fields = $this->address->exclude_keys;

        if($result) {

            $baddress_id = $result['baddress_id'];
            $saddress_id = $result['saddress_id'];

            $result = filter_array_keys($result,$contact_exclude_fields);

            $filter = ['id'=>$baddress_id];
            $baddress = $this->address->single($filter);
            $baddress = filter_array_keys($baddress,$address_exclude_fields);

            $filter = ['id'=>$saddress_id];
            $saddress = $this->address->single($filter);
            $saddress = filter_array_keys($saddress,$address_exclude_fields);

            foreach ($address_keys as $new=>$old) {
                change_array_key($old,$new,$baddress);
            }
            foreach ($address_keys as $new=>$old) {
                change_array_key($old,$new,$saddress);
            }
            $result['billing'] = $baddress;
            $result['shipping'] = $saddress;

            foreach ($contact_keys as $new=>$old) {
                change_array_key($old,$new,$result);
            }

            _response_data('obj',$result);

        }else{
            _set_message('The requested details could not be found.','warning');
            _response_data('redirect',base_url($this->module));
        }
        return true;
    }

    public function _select_data_get() {

        $params = [];
        $params['include_select'] = false;
        $tours = $this->_get_select_data($params);

        _response_data('tours',$tours);
        return true;

    }

    public function _get_select_data($params=[]) {
        $include_select = isset($params['include_select'])?$params['include_select']:true;

        $tours = $this->{$this->model}->get_active_list();
        if($tours) {
            $tours = get_select_array($tours,'id','title',$include_select,'','Select '.$this->singular);
            return $tours;
        }else{
            return [];
        }

    }

    public function _get_vendor_select_data($params=[]) {
        $include_select = isset($params['include_select'])?$params['include_select']:true;

        $filter = ['type'=>'v','status'=>1];
        $result = $this->{$this->model}->search($filter);
        if($result) {
            $result = get_select_array($result,'id','display_name',$include_select,'','Select '.$this->singular);
            return $result;
        }else{
            return [];
        }

    }

    public function _get_customer_select_data($params=[]) {
        $include_select = isset($params['include_select'])?$params['include_select']:true;

        $filter = ['type'=>'c','status'=>1];
        $result = $this->{$this->model}->search($filter);
        if($result) {
            $result = get_select_array($result,'id','display_name',$include_select,'','Select '.$this->singular);
            return $result;
        }else{
            return [];
        }

    }

    public function _get_vendor_data($param=[]) {
        $filter = ['type'=>'v','id'=>$param['vendor_id']];
        $convert_vue = (isset($param['convert_vue']) && $param['convert_vue'])?true:false;
        $result = $this->{$this->model}->single($filter);
        if($result) {
            if($convert_vue) {
                $contact_keys = $this->{$this->model}->keys;
                foreach ($contact_keys as $old => $new) {
                    change_array_key($new,$old,$result);
                }
            }
            return $result;
        }else{
            return [];
        }
    }

    public function _get_customer_data($param=[]) {
        $filter = ['type'=>'c','id'=>$param['customer_id']];
        $convert_vue = (isset($param['convert_vue']) && $param['convert_vue'])?true:false;
        $result = $this->{$this->model}->single($filter);
        if($result) {
            if($convert_vue) {
                $contact_keys = $this->{$this->model}->keys;
                foreach ($contact_keys as $old => $new) {
                    change_array_key($new,$old,$result);
                }
            }
            return $result;
        }else{
            return [];
        }
    }

    public function _get_address_data($param=[]) {
        _model('address');
        $address_id = $param['address_id'];

        $filter = ['id'=>$address_id];
        $convert_vue = (isset($param['convert_vue']) && $param['convert_vue'])?true:false;
        $result = $this->address->single($filter);
        if($result) {
            if($convert_vue) {

            }
            return $result;
        }else{
            return [];
        }
    }*/

    public function _install() {
        return true;
    }

    public function _uninstall() {
        return true;
    }

    protected function _load_files() {
    }
}
