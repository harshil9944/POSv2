<div class="alert <?php echo $class; ?> alert-wth-icon alert-dismissible fade show" role="alert">
    <span class="alert-icon-wrap"><i class="zmdi <?php echo $icon; ?>"></i></span><?php echo $message; ?><button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>