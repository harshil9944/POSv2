<?php echo _get_styles('footer'); ?>
<?php _ejs_vars('f'); ?>
<?php echo _get_scripts('footer'); ?>

