<?php
$cb = $this->brahma;
?>
    </main>
    <?php if(isset($cb->inc_footer) && $cb->inc_footer) { echo $cb->inc_footer; } ?>
</div>

