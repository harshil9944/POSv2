<?php if(_logged_in()){ ?>
<script>new Vue({el:'#page-container'});</script>
<?php } ?>
</body>
</html>
