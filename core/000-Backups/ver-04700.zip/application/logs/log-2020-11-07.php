<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-07 16:47:29 --> 404 Page Not Found: /index
ERROR - 2020-11-07 16:47:30 --> 404 Page Not Found: /index
ERROR - 2020-11-07 17:38:30 --> 404 Page Not Found: /index
ERROR - 2020-11-07 17:38:30 --> 404 Page Not Found: /index
ERROR - 2020-11-07 17:38:35 --> 404 Page Not Found: /index
ERROR - 2020-11-07 17:38:35 --> 404 Page Not Found: /index
ERROR - 2020-11-07 17:38:38 --> 404 Page Not Found: /index
ERROR - 2020-11-07 17:38:53 --> 404 Page Not Found: /index
ERROR - 2020-11-07 17:38:53 --> 404 Page Not Found: /index
ERROR - 2020-11-07 18:21:55 --> 404 Page Not Found: /index
ERROR - 2020-11-07 18:21:55 --> 404 Page Not Found: /index
ERROR - 2020-11-07 18:21:56 --> 404 Page Not Found: /index
ERROR - 2020-11-07 18:21:56 --> 404 Page Not Found: /index
ERROR - 2020-11-07 18:21:56 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:45 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:46 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:46 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:46 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:46 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:46 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:46 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:46 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:49 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:49 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:49 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:13:49 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:15:07 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:15:07 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:15:07 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:15:07 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:15:38 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:17:36 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:17:36 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:17:36 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:17:36 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:17:49 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:17:49 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:17:49 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:17:49 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:18:53 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:18:53 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:18:53 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:18:54 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:21:56 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:23:12 --> 404 Page Not Found: /index
ERROR - 2020-11-07 19:23:12 --> 404 Page Not Found: /index
ERROR - 2020-11-07 21:56:35 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 21:58:46 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 21:58:46 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 21:58:47 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 21:58:47 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 21:58:47 --> 404 Page Not Found: /index
ERROR - 2020-11-07 21:58:47 --> 404 Page Not Found: /index
ERROR - 2020-11-07 21:59:31 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 21:59:33 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 21:59:33 --> 404 Page Not Found: /index
ERROR - 2020-11-07 21:59:33 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 21:59:33 --> 404 Page Not Found: /index
ERROR - 2020-11-07 21:59:35 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:00:50 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:00:50 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:00:50 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:00:50 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:00:50 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:01:48 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:01:48 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:01:48 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:01:48 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:01:48 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:03:15 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:03:18 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:03:19 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:03:19 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:04:25 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:04:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:09:16 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:10:58 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:11:43 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:12:14 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:13:14 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:13:28 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:13:48 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:14:13 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:14:50 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:15:30 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:15:53 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:19:06 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:19:08 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:21:23 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:21:23 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given E:\2020\I\InnTechPOS-Dev\core\application\helpers\template_helper.php 229
ERROR - 2020-11-07 22:21:23 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given E:\2020\I\InnTechPOS-Dev\core\application\helpers\template_helper.php 229
ERROR - 2020-11-07 22:21:48 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:21:57 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:22:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:22:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:22:08 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:22:40 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:24:10 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:24:16 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:24:16 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:24:20 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:24:59 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:25:05 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:26:12 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:26:17 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:27:07 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:27:12 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:22 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:26 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:28 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:28 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:28 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:29:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:29 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:29:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:29 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:29:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:30 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:30 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:29:30 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:29:30 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:33:28 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:33:28 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:33:28 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:33:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:33:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:33:29 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:33:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:33:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:33:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:33:29 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:33:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:33:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:33:30 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:34:41 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:34:42 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:34:42 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:34:42 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:34:42 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:34:42 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:34:42 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:34:42 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:34:42 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:34:42 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:34:42 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:34:43 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:35:47 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:35:47 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:35:47 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:35:48 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:35:48 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:35:48 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:35:48 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:35:48 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:35:51 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:35:51 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:37:05 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:06 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:06 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:06 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:06 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:06 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:14 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:20 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:22 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:23 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:23 --> 404 Page Not Found: /index
ERROR - 2020-11-07 22:37:24 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:24 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:27 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:32 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:32 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:33 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:33 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:33 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:33 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:37:33 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:04 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:04 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:04 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:04 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:04 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:42 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:42 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:42 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:42 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:43 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:39:43 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:02 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:14 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:15 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:15 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:15 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:15 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:15 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:37 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:37 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:38 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:38 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:38 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:38 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:40:58 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:41:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:41:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:41:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:41:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:41:03 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:41:04 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:41:04 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:41:27 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:44:24 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:44:24 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:44:25 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:44:25 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:44:25 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:44:25 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
ERROR - 2020-11-07 22:51:29 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
