<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-04 09:35:10 --> 404 Page Not Found: /index
ERROR - 2020-11-04 09:35:10 --> 404 Page Not Found: /index
ERROR - 2020-11-04 10:44:06 --> 404 Page Not Found: /index
ERROR - 2020-11-04 10:44:06 --> 404 Page Not Found: /index
