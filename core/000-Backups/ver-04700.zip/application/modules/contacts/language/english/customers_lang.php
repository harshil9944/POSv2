<?php
$lang['text_name'] = 'Name';
$lang['text_company_name'] = 'Company Name';
$lang['text_email'] = 'Email';
$lang['text_phone'] = 'Phone';
$lang['text_receivables'] = 'Receivables';
$lang['text_payables'] = 'Payables';
$lang['text_action'] = 'Action';
