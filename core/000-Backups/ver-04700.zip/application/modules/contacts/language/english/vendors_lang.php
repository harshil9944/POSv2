<?php
$lang['text_first_name'] = 'First Name';

$lang['text_action'] = 'Action';
