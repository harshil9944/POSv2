<?php
defined('USER_TABLE')           OR  define('USER_TABLE', 'usr_user');
defined('USER_PROFILE_TABLE')   OR  define('USER_PROFILE_TABLE', 'usr_profile');
defined('USER_GROUP_TABLE')     OR  define('USER_GROUP_TABLE', 'usr_group');
defined('USER_FORGOT_TABLE')    OR  define('USER_FORGOT_TABLE', 'usr_forgot');