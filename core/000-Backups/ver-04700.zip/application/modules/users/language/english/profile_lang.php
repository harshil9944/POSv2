<?php
$lang['text_first_name'] = 'First Name';
