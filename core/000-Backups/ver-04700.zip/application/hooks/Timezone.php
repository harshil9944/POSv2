<?php
class Timezone
{
    public function setSystemTimezone() {
        _set_timezone();
    }
}