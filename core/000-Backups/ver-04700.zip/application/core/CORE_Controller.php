<?php
class CORE_Controller extends MX_Controller {
	function __construct ()
	{
		parent::__construct();
	}
}
