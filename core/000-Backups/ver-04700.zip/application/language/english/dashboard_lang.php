<?php
$lang['text_page_heading'] = 'Dashboard';
